using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitAction : MonoBehaviour
{

    Vector3 _destPos;
    float _moveSpeed = 1.0f;
    public bool _onAction;

    void Start()
    {
        
    }
    void Update()
    {
        
    }

    public void Move(Vector3 destPos)
    {
        _destPos = destPos;
        StartCoroutine( MoveAction() );
    }

    IEnumerator MoveAction()
    {
        _onAction = true;

        while (true)
        {
            transform.position = Vector3.MoveTowards(transform.position, _destPos, _moveSpeed * Time.deltaTime);

            yield return null;

            if (transform.position == _destPos)
            {
                yield return new WaitForSeconds(0.5f);
                break;
            }
                
        }

        _onAction = false;
    }
}
